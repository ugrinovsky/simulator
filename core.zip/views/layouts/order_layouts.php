<!DOCTYPE>

<html>
	<head>
			<meta name="keywords" content="" />
			<meta name="description" content="" />
			<meta charset="utf-8">
			<title></title>
	</head>
<body>
	<?php
		include($contentPage);
	?>	
</body>
</html>
