<div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-4 col-md-offset-4 auth">
            <h1 class="text-center login-title">Пожалуйста, авторизуйтесь</h1>
            <div class="account-wall">
                <img class="profile-img" src="https://lh5.googleusercontent.com/-b0-k99FZlyE/AAAAAAAAAAI/AAAAAAAAAAA/eu7opA4byxI/photo.jpg?sz=120"
                    alt="">
                <form action="/auth" method="post" class="form-signin">
	                <input name="login" type="text" class="form-control" placeholder="Логин" required autofocus>
	                <input name="pass" type="password" class="form-control" placeholder="Пароль" required>
	                <button class="btn btn-lg btn-default btn-block" type="submit">
	                	Войти
	                </button>
                </form>
            </div>
        </div>
    </div>
</div>