	<?php include_once('_menu.php') ?>
	<h3>
		Статистика по заводам
	</h3>
	<div class="row">
		<div class="col-md-8">
			<div class="panel panel-default">
				<div class="panel-heading">
					Динамика
				</div>
			</div>
			<div class="flot-chart">
				<div class="flot-chart-content" id="flot-line-chart"></div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading">
					График расходов
				</div>
			</div>
			<div class="flot-chart">
				<div class="flot-chart-content" id="morris-bar-chart"></div>
			</div>
		</div>
	</div>
	<hr>
</div>